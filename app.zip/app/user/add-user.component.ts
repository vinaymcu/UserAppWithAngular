import { Component } from '@angular/core';
import { Router } from '@angular/router';

//import {MatCheckboxModule} from '@angular/material/checkbox';

import { User } from '../models/user.model';
import { UserService } from './user.service';
import { FormControl } from "@angular/forms";
import { Validators } from "@angular/forms";

import {item} from '../user/item.model';
import {ITEMS} from '../user/mock-data';


@Component({

  templateUrl: './add-user.component.html'
  
})
export class AddUserComponent {

  user: User = new User();
  favoriteSeason: string;
  
  seasons: string[] = ['Winter', 'Spring', 'Summer', 'Autumn'];
  isavailable = false;


  radioSel:any;
  radioSelected:string;
  radioSelectedString:string;
  itemsList: item[] = ITEMS;

  constructor(private router: Router,
  private userService: UserService) {

    this.itemsList = ITEMS;
    this.radioSelected = "item_3";
    this.getSelecteditem();
  }

  createUser(): void {
    console.log(this.user.gender);
    console.log(this.user.city);
    this.userService.createUser(this.user)
        .subscribe( data => {
          alert("User created successfully.");
        });

  };


  resetUser():void{
    this.user.firstName="";
    this.user.lastName="";
    this.user.city="";
    this.user.email="";

  }

  getSelecteditem(){
    this.radioSel = ITEMS.find(Item => Item.value === this.radioSelected);
    this.radioSelectedString = JSON.stringify(this.radioSel);
  }

  onItemChange(item){
    this.getSelecteditem();
  }

}
