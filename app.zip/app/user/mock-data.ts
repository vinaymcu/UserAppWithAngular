import { item} from './item.model';
 
export const ITEMS: item[] = [
    {
        name:'male',
        value:'Male'
     },
     {
         name:'female',
         value:'Female'
      },
      {
          name:'other',
          value:'Other'
       }
];