export class item{
    name:string;
    value:string;
}