export class User {

  id: string;
  firstName: string;
  lastName: string;
  email: string;
  city:string;
  gender:string;
  isMarried: boolean = false;
}
